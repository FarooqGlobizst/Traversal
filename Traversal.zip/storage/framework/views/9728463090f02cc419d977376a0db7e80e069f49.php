<!--/w3l-bottom-->
<section class="w3l-bottom py-5">
    <div class="container py-md-4 py-3 text-center">
      <div class="row my-lg-4 mt-4">
        <div class="col-lg-9 col-md-10 ml-auto">
          <div class="bottom-info ml-auto">
            <div class="header-section text-left">
              <h3 class="hny-title two">Traveling makes a man wiser, but less happy.</h3>
              <p class="mt-3 pr-lg-5">Lorem ipsum dolor sit amet consectetur adipisicing elit. Velit beatae laudantium
                voluptate rem ullam dolore nisi voluptatibus esse quasi. Integer sit amet .Lorem ipsum dolor sit
                amet adipisicing elit.</p>
              <a href="about.html" class="btn btn-style btn-secondary mt-5">Read More</a>
            </div>
           

          </div>
        </div>
      </div>
    </div>
  </section>
  <!--//w3l-bottom--><?php /**PATH C:\xampp\htdocs\Traversal\resources\views/main/bottom.blade.php ENDPATH**/ ?>