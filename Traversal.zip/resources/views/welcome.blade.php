@extends('layouts.base')

@section('content')
@include('layouts.banner')
@include('main.grids')

@endsection